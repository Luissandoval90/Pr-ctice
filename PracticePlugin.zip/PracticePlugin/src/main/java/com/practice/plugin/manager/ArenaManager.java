package com.practice.plugin.manager;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Arena;
import com.practice.plugin.model.ArenaType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Administra la creacion, guardado y disponibilidad de arenas de combate.
 */
public class ArenaManager {

    private final PracticePlugin plugin;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();
    private File file;

    public ArenaManager(PracticePlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "arenas.yml");
        if (!file.exists()) return;
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = config.getConfigurationSection("arenas");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);
            if (section == null) continue;
            Arena arena = new Arena(key);
            arena.setType(ArenaType.valueOf(section.getString("type", "NORMAL")));
            arena.setPos1(section.getLocation("pos1"));
            arena.setPos2(section.getLocation("pos2"));
            arena.setSpawn1(section.getLocation("spawn1"));
            arena.setSpawn2(section.getLocation("spawn2"));
            arenas.put(key.toLowerCase(), arena);
        }
    }

    public void saveAll() {
        FileConfiguration config = new YamlConfiguration();
        for (Arena arena : arenas.values()) {
            String path = "arenas." + arena.getName();
            config.set(path + ".type", arena.getType().name());
            if (arena.getPos1() != null) config.set(path + ".pos1", arena.getPos1());
            if (arena.getPos2() != null) config.set(path + ".pos2", arena.getPos2());
            if (arena.getSpawn1() != null) config.set(path + ".spawn1", arena.getSpawn1());
            if (arena.getSpawn2() != null) config.set(path + ".spawn2", arena.getSpawn2());
        }
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("No se pudo guardar arenas.yml: " + e.getMessage());
        }
    }

    public Arena create(String name) {
        Arena arena = new Arena(name);
        arenas.put(name.toLowerCase(), arena);
        return arena;
    }

    public Arena get(String name) {
        return arenas.get(name.toLowerCase());
    }

    public boolean exists(String name) {
        return arenas.containsKey(name.toLowerCase());
    }

    public void delete(String name) {
        arenas.remove(name.toLowerCase());
        saveAll();
    }

    public List<Arena> getArenas() {
        return new ArrayList<>(arenas.values());
    }

    /** Busca una arena libre y completamente configurada para el kit dado. */
    public Arena findFreeArena() {
        for (Arena arena : arenas.values()) {
            if (!arena.isInUse() && arena.isFullySet()) {
                return arena;
            }
        }
        return null;
    }
}
