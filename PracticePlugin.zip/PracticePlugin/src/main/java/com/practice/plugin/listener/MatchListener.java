package com.practice.plugin.listener;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Kit;
import com.practice.plugin.model.Match;
import com.practice.plugin.model.MatchState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.UUID;

/**
 * Controla todas las reglas dentro de una partida activa: dano,
 * muerte -> eliminacion, construccion segun el kit, hambre, regen
 * natural, y limites de la arena (para kits tipo sumo/spleef).
 */
public class MatchListener implements Listener {

    private final PracticePlugin plugin;

    public MatchListener(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());

        if (match == null) {
            // fuera de partida: sin PvP ni dano en el lobby
            event.setCancelled(true);
            return;
        }

        if (match.getState() != MatchState.RUNNING) {
            event.setCancelled(true);
            return;
        }

        Kit kit = match.getKit();
        if (!kit.isFallDamage() && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
            return;
        }

        double finalDamage = event.getFinalDamage();
        if (player.getHealth() - finalDamage <= 0.0) {
            event.setCancelled(true);
            player.setHealth(1.0);
            Player killer = null;
            if (event instanceof EntityDamageByEntityEvent byEntity) {
                if (byEntity.getDamager() instanceof Player p) killer = p;
                else if (byEntity.getDamager() instanceof org.bukkit.entity.Projectile projectile
                        && projectile.getShooter() instanceof Player p) killer = p;
            }
            plugin.getMatchManager().handleElimination(match, player, killer);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        Player attacker = resolvePlayerAttacker(event);
        if (attacker == null) return;

        Match match = plugin.getMatchManager().getMatch(victim.getUniqueId());
        Match attackerMatch = plugin.getMatchManager().getMatch(attacker.getUniqueId());

        if (match == null || attackerMatch == null || !match.equals(attackerMatch)) {
            event.setCancelled(true);
            return;
        }

        // evitar fuego amigo entre miembros del mismo equipo (no aplica en partidas FFA)
        if (!match.isFfa()) {
            var team = match.getTeamOf(victim.getUniqueId());
            if (team != null && team.contains(attacker.getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }

    private Player resolvePlayerAttacker(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player p) return p;
        if (event.getDamager() instanceof org.bukkit.entity.Projectile projectile
                && projectile.getShooter() instanceof Player p) return p;
        return null;
    }

    @EventHandler
    public void onRegen(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        if (match == null) return;
        if (event.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED
                && !match.getKit().isNaturalRegen()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onFoodChange(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        if (match == null) return;
        if (!match.getKit().isHungerLoss()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        // fuera de una partida, el plugin no interfiere (permite a los admins construir arenas)
        if (match == null) return;
        if (!match.getKit().isAllowBuild()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        if (match == null) return;
        if (!match.getKit().isAllowBuild()) {
            event.setCancelled(true);
        }
    }

    /** Detecta que un jugador caiga al vacio en kits tipo sumo/spleef para eliminarlo sin dano de espada. */
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        if (match == null || match.getState() != MatchState.RUNNING) return;
        if (match.getKit().isFallDamage()) return; // solo aplica a kits sin dano de caida (sumo, spleef)

        double threshold;
        var arena = match.getArena();
        if (arena.getPos1() != null && arena.getPos2() != null) {
            threshold = Math.min(arena.getPos1().getY(), arena.getPos2().getY()) - 5;
        } else {
            threshold = -10;
        }

        if (player.getLocation().getY() < threshold) {
            plugin.getMatchManager().handleElimination(match, player, null);
        }
    }
}
