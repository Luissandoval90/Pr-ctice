package com.practice.plugin.model;

import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa un kit configurable: items de inventario, armadura,
 * efectos de pocion permanentes, y reglas especiales de la partida
 * (natural regen, hunger, construccion permitida, knockback, etc).
 */
public class Kit {

    private final String name;
    private KitType type;
    private ItemStack[] items = new ItemStack[36];
    private ItemStack[] armor = new ItemStack[4];
    private List<PotionEffect> effects = new ArrayList<>();

    private boolean allowBuild = false;
    private boolean naturalRegen = true;
    private boolean hungerLoss = true;
    private boolean fallDamage = true;
    private double knockbackMultiplier = 1.0;
    private boolean icon = true;

    public Kit(String name, KitType type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public KitType getType() {
        return type;
    }

    public void setType(KitType type) {
        this.type = type;
    }

    public ItemStack[] getItems() {
        return items;
    }

    public void setItems(ItemStack[] items) {
        this.items = items;
    }

    public ItemStack[] getArmor() {
        return armor;
    }

    public void setArmor(ItemStack[] armor) {
        this.armor = armor;
    }

    public List<PotionEffect> getEffects() {
        return effects;
    }

    public void setEffects(List<PotionEffect> effects) {
        this.effects = effects;
    }

    public boolean isAllowBuild() {
        return allowBuild;
    }

    public void setAllowBuild(boolean allowBuild) {
        this.allowBuild = allowBuild;
    }

    public boolean isNaturalRegen() {
        return naturalRegen;
    }

    public void setNaturalRegen(boolean naturalRegen) {
        this.naturalRegen = naturalRegen;
    }

    public boolean isHungerLoss() {
        return hungerLoss;
    }

    public void setHungerLoss(boolean hungerLoss) {
        this.hungerLoss = hungerLoss;
    }

    public boolean isFallDamage() {
        return fallDamage;
    }

    public void setFallDamage(boolean fallDamage) {
        this.fallDamage = fallDamage;
    }

    public double getKnockbackMultiplier() {
        return knockbackMultiplier;
    }

    public void setKnockbackMultiplier(double knockbackMultiplier) {
        this.knockbackMultiplier = knockbackMultiplier;
    }
}
