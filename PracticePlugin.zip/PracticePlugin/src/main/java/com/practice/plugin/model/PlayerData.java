package com.practice.plugin.model;

import java.util.UUID;

/**
 * Estadisticas persistentes de un jugador (guardadas en stats.yml).
 */
public class PlayerData {

    private final UUID uuid;
    private int wins = 0;
    private int losses = 0;
    private int killstreak = 0;
    private int bestKillstreak = 0;

    // estado en caliente (no persistente)
    private boolean inMatch = false;
    private boolean inQueue = false;
    private ItemSnapshot preMatchInventory;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() {
        return uuid;
    }

    public int getWins() {
        return wins;
    }

    public void addWin() {
        wins++;
        killstreak++;
        if (killstreak > bestKillstreak) bestKillstreak = killstreak;
    }

    public int getLosses() {
        return losses;
    }

    public void addLoss() {
        losses++;
        killstreak = 0;
    }

    public int getKillstreak() {
        return killstreak;
    }

    public int getBestKillstreak() {
        return bestKillstreak;
    }

    public boolean isInMatch() {
        return inMatch;
    }

    public void setInMatch(boolean inMatch) {
        this.inMatch = inMatch;
    }

    public boolean isInQueue() {
        return inQueue;
    }

    public void setInQueue(boolean inQueue) {
        this.inQueue = inQueue;
    }

    public ItemSnapshot getPreMatchInventory() {
        return preMatchInventory;
    }

    public void setPreMatchInventory(ItemSnapshot preMatchInventory) {
        this.preMatchInventory = preMatchInventory;
    }

    public double getWinRate() {
        int total = wins + losses;
        if (total == 0) return 0;
        return (wins * 100.0) / total;
    }
}
