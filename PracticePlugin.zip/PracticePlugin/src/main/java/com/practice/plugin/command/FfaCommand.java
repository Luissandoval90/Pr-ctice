package com.practice.plugin.command;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Kit;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * /ffa <kit>  - entra o sale de la cola de "todos contra todos" para ese kit.
 * Cuando hay 3 o mas jugadores en cola, la partida arranca automaticamente
 * a los 15 segundos (o antes si un admin la fuerza).
 */
public class FfaCommand implements CommandExecutor {

    private final PracticePlugin plugin;
    private static final int MIN_PLAYERS = 3;
    private static final Set<UUID> queue = ConcurrentHashMap.newKeySet();
    private static String queuedKit = null;
    private static boolean timerRunning = false;

    public FfaCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtil.c(plugin.msg("player-only")));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(ColorUtil.c("&cUso: /ffa <kit>  (usalo de nuevo para salir de la cola)"));
            return true;
        }
        String kitName = args[0].toLowerCase();
        if (!plugin.getKitManager().exists(kitName)) {
            player.sendMessage(ColorUtil.c(plugin.msg("kit-not-found")));
            return true;
        }

        if (queue.contains(player.getUniqueId())) {
            queue.remove(player.getUniqueId());
            player.sendMessage(ColorUtil.c("&eHas salido de la cola FFA."));
            return true;
        }

        if (plugin.getMatchManager().isInMatch(player.getUniqueId())) {
            player.sendMessage(ColorUtil.c("&cYa estas en una partida."));
            return true;
        }

        if (queuedKit != null && !queuedKit.equalsIgnoreCase(kitName) && !queue.isEmpty()) {
            player.sendMessage(ColorUtil.c("&cYa hay una cola FFA abierta para el kit &f" + queuedKit + "&c. Unete a esa."));
            return true;
        }

        queuedKit = kitName;
        queue.add(player.getUniqueId());
        player.sendMessage(ColorUtil.c("&aTe has unido a la cola FFA (&f" + kitName + "&a). Jugadores en cola: &f" + queue.size()));

        if (queue.size() >= MIN_PLAYERS && !timerRunning) {
            timerRunning = true;
            broadcastQueue("&eLa partida FFA comenzara en 15 segundos. Usa /ffa " + kitName + " para unirte.");
            new BukkitRunnable() {
                @Override
                public void run() {
                    timerRunning = false;
                    if (queue.size() < MIN_PLAYERS) {
                        broadcastQueue("&cNo hay suficientes jugadores, la partida FFA se ha cancelado.");
                        return;
                    }
                    Set<UUID> players = new LinkedHashSet<>(queue);
                    queue.clear();
                    Kit kit = plugin.getKitManager().getKit(queuedKit);
                    queuedKit = null;
                    plugin.getMatchManager().startFfaMatch(players, kit);
                }
            }.runTaskLater(plugin, 15 * 20L);
        }
        return true;
    }

    private void broadcastQueue(String message) {
        for (UUID uuid : queue) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(ColorUtil.c(plugin.prefix() + message));
        }
    }
}
