package com.practice.plugin.command;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.PlayerData;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /practice reload   - recarga config, mensajes, kits y arenas
 * /practice stats [jugador]
 * /practice arenas
 * /practice kits
 * /practice leave    - abandona la partida actual
 */
public class PracticeAdminCommand implements CommandExecutor {

    private final PracticePlugin plugin;

    public PracticeAdminCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ColorUtil.c("&cUso: /practice <reload|stats|arenas|kits|leave>"));
            return true;
        }
        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload" -> {
                if (!sender.hasPermission("practice.admin")) {
                    sender.sendMessage(ColorUtil.c(plugin.msg("no-permission")));
                    return true;
                }
                plugin.reloadConfig();
                plugin.getKitManager().load();
                plugin.getArenaManager().load();
                sender.sendMessage(ColorUtil.c("&aConfiguracion, kits y arenas recargados."));
            }
            case "stats" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1])
                        : (sender instanceof Player p ? p : null);
                if (target == null) {
                    sender.sendMessage(ColorUtil.c("&cJugador no encontrado."));
                    return true;
                }
                PlayerData data = plugin.getPlayerDataManager().get(target.getUniqueId());
                sender.sendMessage(ColorUtil.c("&b--- Estadisticas de " + target.getName() + " ---"));
                sender.sendMessage(ColorUtil.c("&fVictorias: &a" + data.getWins()));
                sender.sendMessage(ColorUtil.c("&fDerrotas: &c" + data.getLosses()));
                sender.sendMessage(ColorUtil.c("&fRacha actual: &e" + data.getKillstreak()));
                sender.sendMessage(ColorUtil.c("&fMejor racha: &6" + data.getBestKillstreak()));
                sender.sendMessage(ColorUtil.c(String.format("&fRatio de victorias: &d%.1f%%", data.getWinRate())));
            }
            case "arenas" -> {
                long total = plugin.getArenaManager().getArenas().size();
                long free = plugin.getArenaManager().getArenas().stream().filter(a -> !a.isInUse()).count();
                sender.sendMessage(ColorUtil.c("&bArenas totales: &f" + total + " &7| &bLibres: &a" + free));
            }
            case "kits" -> sender.sendMessage(ColorUtil.c("&bKits totales: &f" + plugin.getKitManager().getKits().size()));
            case "leave" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(ColorUtil.c(plugin.msg("player-only")));
                    return true;
                }
                if (!plugin.getMatchManager().isInMatch(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.c("&cNo estas en ninguna partida."));
                    return true;
                }
                plugin.getMatchManager().forfeit(player);
            }
            default -> sender.sendMessage(ColorUtil.c("&cUso: /practice <reload|stats|arenas|kits|leave>"));
        }
        return true;
    }
}
