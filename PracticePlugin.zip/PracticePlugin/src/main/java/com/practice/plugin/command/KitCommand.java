package com.practice.plugin.command;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Kit;
import com.practice.plugin.model.KitType;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.stream.Collectors;

/**
 * /kit crear <nombre> [tipo]   - crea un kit con tu inventario actual
 * /kit borrar <nombre>          - elimina un kit
 * /kit editar <nombre>          - sobreescribe un kit con tu inventario actual
 * /kit lista                    - lista todos los kits
 */
public class KitCommand implements CommandExecutor {

    private final PracticePlugin plugin;

    public KitCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ColorUtil.c("&cUso: /kit <crear|borrar|editar|lista> [nombre]"));
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("lista")) {
            String kits = plugin.getKitManager().getKits().stream()
                    .map(Kit::getName)
                    .collect(Collectors.joining(", "));
            sender.sendMessage(ColorUtil.c(plugin.msg("kit-list").replace("%kits%", kits)));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtil.c(plugin.msg("player-only")));
            return true;
        }

        if (!player.hasPermission("practice.admin")) {
            player.sendMessage(ColorUtil.c(plugin.msg("no-permission")));
            return true;
        }

        switch (sub) {
            case "crear" -> {
                if (args.length < 2) {
                    player.sendMessage(ColorUtil.c("&cUso: /kit crear <nombre> [tipo]"));
                    return true;
                }
                String name = args[1];
                KitType type = args.length > 2 ? KitType.fromString(args[2]) : KitType.CUSTOM;
                Kit kit = new Kit(name, type);
                kit.setItems(player.getInventory().getContents().clone());
                kit.setArmor(player.getInventory().getArmorContents().clone());
                plugin.getKitManager().addKit(kit);
                player.sendMessage(ColorUtil.c(plugin.msg("kit-created").replace("%kit%", name)));
            }
            case "editar" -> {
                if (args.length < 2) {
                    player.sendMessage(ColorUtil.c("&cUso: /kit editar <nombre>"));
                    return true;
                }
                String name = args[1];
                Kit kit = plugin.getKitManager().getKit(name);
                if (kit == null) {
                    player.sendMessage(ColorUtil.c(plugin.msg("kit-not-found")));
                    return true;
                }
                kit.setItems(player.getInventory().getContents().clone());
                kit.setArmor(player.getInventory().getArmorContents().clone());
                plugin.getKitManager().saveAll();
                player.sendMessage(ColorUtil.c(plugin.msg("kit-created").replace("%kit%", name)));
            }
            case "borrar" -> {
                if (args.length < 2) {
                    player.sendMessage(ColorUtil.c("&cUso: /kit borrar <nombre>"));
                    return true;
                }
                String name = args[1];
                if (!plugin.getKitManager().exists(name)) {
                    player.sendMessage(ColorUtil.c(plugin.msg("kit-not-found")));
                    return true;
                }
                plugin.getKitManager().deleteKit(name);
                player.sendMessage(ColorUtil.c(plugin.msg("kit-deleted").replace("%kit%", name)));
            }
            default -> player.sendMessage(ColorUtil.c("&cUso: /kit <crear|borrar|editar|lista> [nombre]"));
        }
        return true;
    }
}
