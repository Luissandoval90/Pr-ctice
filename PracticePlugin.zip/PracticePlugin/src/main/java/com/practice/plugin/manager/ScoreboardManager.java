package com.practice.plugin.manager;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Match;
import com.practice.plugin.model.PlayerData;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Crea y actualiza el scoreboard lateral de cada jugador, tanto en el
 * lobby como durante una partida activa.
 */
public class ScoreboardManager {

    private final PracticePlugin plugin;

    public ScoreboardManager(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    update(player);
                }
            }
        }.runTaskTimer(plugin, 0L, plugin.getConfig().getLong("scoreboard.update-interval-ticks", 20L));
    }

    public void update(Player player) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;

        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective("practice", "dummy",
                ColorUtil.c(plugin.getConfig().getString("scoreboard.title", "&b&lPRACTICE")));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        List<String> lines = new ArrayList<>();
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());

        if (match != null) {
            lines.add("&7--------------------");
            lines.add("&fKit: &b" + match.getKit().getName());
            lines.add("&fModo: &b" + match.getTeamA().size() + "vs" + match.getTeamB().size());
            lines.add("&fVivos: &a" + match.getAlive().size() + "&7/&f" + match.totalPlayers());
            lines.add(" ");
            lines.add("&fArena: &b" + match.getArena().getName());
            lines.add("&7--------------------");
        } else {
            lines.add("&7--------------------");
            lines.add("&fJugador: &b" + player.getName());
            lines.add(" ");
            lines.add("&fVictorias: &a" + data.getWins());
            lines.add("&fDerrotas: &c" + data.getLosses());
            lines.add("&fRacha: &e" + data.getKillstreak());
            lines.add(" ");
            lines.add("&fEstado: " + (data.isInQueue() ? "&eEn cola" : "&7En el lobby"));
            lines.add("&7--------------------");
        }

        int score = lines.size();
        for (String line : lines) {
            // las lineas duplicadas necesitan espacios invisibles unicos
            String entry = ColorUtil.c(line);
            while (board.getEntries().contains(entry)) {
                entry += ChatColor.RESET;
            }
            objective.getScore(entry).setScore(score--);
        }

        player.setScoreboard(board);
    }
}
