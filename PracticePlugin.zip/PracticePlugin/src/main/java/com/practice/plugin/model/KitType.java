package com.practice.plugin.model;

/**
 * Tipos de kit predefinidos por el plugin. Sirven como plantilla inicial,
 * pero el admin puede crear kits ilimitados adicionales con /kit crear <nombre>.
 */
public enum KitType {
    SWORD,
    UHC,
    POT,          // Potion PvP
    NODEBUFF,
    DEBUFF,
    BOXING,       // Sin armadura, solo punos
    SUMO,         // Empujar fuera de la plataforma, sin danio de items
    GAPPLE,       // Golden apple fight
    AXE,          // Combate con hachas
    BUILD,        // Bridge / construccion
    SOUP,         // Soup PvP
    COMBO,        // Combo (knockback alto, sin regen)
    SPLEEF,       // Spleef con palas
    CUSTOM;

    public static KitType fromString(String s) {
        try {
            return KitType.valueOf(s.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return CUSTOM;
        }
    }
}
