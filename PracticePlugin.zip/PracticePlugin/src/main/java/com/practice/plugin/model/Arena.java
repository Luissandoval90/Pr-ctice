package com.practice.plugin.model;

import org.bukkit.Location;
import org.bukkit.block.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa una arena/mapa de duelo. Cada arena tiene dos puntos de
 * spawn (para equipo A y equipo B / jugador A y B) y opcionalmente
 * puede soportar mas spawns dispersos para partidas NvN grandes.
 */
public class Arena {

    private final String name;
    private ArenaType type = ArenaType.NORMAL;
    private Location pos1;
    private Location pos2;
    private Location spawn1;
    private Location spawn2;
    private boolean inUse = false;

    // snapshot de bloques para arenas BUILD, se rellena al iniciar la partida
    private transient List<BlockState> snapshot = new ArrayList<>();

    public Arena(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ArenaType getType() {
        return type;
    }

    public void setType(ArenaType type) {
        this.type = type;
    }

    public Location getPos1() {
        return pos1;
    }

    public void setPos1(Location pos1) {
        this.pos1 = pos1;
    }

    public Location getPos2() {
        return pos2;
    }

    public void setPos2(Location pos2) {
        this.pos2 = pos2;
    }

    public Location getSpawn1() {
        return spawn1;
    }

    public void setSpawn1(Location spawn1) {
        this.spawn1 = spawn1;
    }

    public Location getSpawn2() {
        return spawn2;
    }

    public void setSpawn2(Location spawn2) {
        this.spawn2 = spawn2;
    }

    public boolean isInUse() {
        return inUse;
    }

    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }

    public boolean isFullySet() {
        return pos1 != null && pos2 != null && spawn1 != null && spawn2 != null;
    }

    public List<BlockState> getSnapshot() {
        return snapshot;
    }

    public void setSnapshot(List<BlockState> snapshot) {
        this.snapshot = snapshot;
    }
}
