package com.practice.plugin.listener;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Match;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Gestiona la entrada/salida de jugadores: teletransporte al spawn,
 * actualizacion de scoreboard y forfeit automatico si estaban en una
 * partida al desconectarse.
 */
public class PlayerConnectionListener implements Listener {

    private final PracticePlugin plugin;

    public PlayerConnectionListener(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getScoreboardManager().update(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Match match = plugin.getMatchManager().getMatch(player.getUniqueId());
        if (match != null) {
            plugin.getMatchManager().forfeit(player);
        }
        if (plugin.getPartyManager().isInParty(player.getUniqueId())) {
            plugin.getPartyManager().leave(player.getUniqueId());
        }
    }
}
