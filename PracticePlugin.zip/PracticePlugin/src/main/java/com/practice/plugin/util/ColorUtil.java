package com.practice.plugin.util;

import org.bukkit.ChatColor;

/**
 * Utilidad simple para traducir codigos de color '&' a colores de Minecraft.
 */
public final class ColorUtil {

    private ColorUtil() {}

    public static String c(String input) {
        if (input == null) return "";
        return ChatColor.translateAlternateColorCodes('&', input);
    }
}
