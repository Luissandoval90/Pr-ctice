package com.practice.plugin.model;

public enum ArenaType {
    NORMAL,   // No se puede romper/poner bloques
    BUILD     // Permite construir, se regenera al terminar la partida
}
