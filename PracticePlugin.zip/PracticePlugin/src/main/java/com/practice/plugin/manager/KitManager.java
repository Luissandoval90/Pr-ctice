package com.practice.plugin.manager;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Kit;
import com.practice.plugin.model.KitType;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Administra la creacion, carga, guardado y borrado de kits.
 * Incluye una libreria de kits predefinidos (sword, uhc, pot, etc.)
 * que se generan automaticamente la primera vez que arranca el plugin,
 * y permite crear kits nuevos ilimitados desde el inventario del admin.
 */
public class KitManager {

    private final PracticePlugin plugin;
    private final Map<String, Kit> kits = new LinkedHashMap<>();
    private File file;

    public KitManager(PracticePlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "kits.yml");
        if (!file.exists()) {
            createDefaultKits();
            saveAll();
            return;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = config.getConfigurationSection("kits");
        if (root == null) {
            createDefaultKits();
            saveAll();
            return;
        }
        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);
            if (section == null) continue;
            Kit kit = new Kit(key, KitType.fromString(section.getString("type", "CUSTOM")));

            List<?> rawItems = section.getList("items");
            ItemStack[] items = new ItemStack[36];
            if (rawItems != null) {
                for (int i = 0; i < rawItems.size() && i < 36; i++) {
                    Object o = rawItems.get(i);
                    if (o instanceof ItemStack) items[i] = (ItemStack) o;
                }
            }
            kit.setItems(items);

            List<?> rawArmor = section.getList("armor");
            ItemStack[] armor = new ItemStack[4];
            if (rawArmor != null) {
                for (int i = 0; i < rawArmor.size() && i < 4; i++) {
                    Object o = rawArmor.get(i);
                    if (o instanceof ItemStack) armor[i] = (ItemStack) o;
                }
            }
            kit.setArmor(armor);

            kit.setAllowBuild(section.getBoolean("allow-build", false));
            kit.setNaturalRegen(section.getBoolean("natural-regen", true));
            kit.setHungerLoss(section.getBoolean("hunger-loss", true));
            kit.setFallDamage(section.getBoolean("fall-damage", true));
            kit.setKnockbackMultiplier(section.getDouble("knockback-multiplier", 1.0));

            List<PotionEffect> effects = new ArrayList<>();
            List<?> rawEffects = section.getList("effects");
            if (rawEffects != null) {
                for (Object o : rawEffects) {
                    if (o instanceof PotionEffect) effects.add((PotionEffect) o);
                }
            }
            kit.setEffects(effects);

            kits.put(key.toLowerCase(), kit);
        }
        if (kits.isEmpty()) {
            createDefaultKits();
            saveAll();
        }
    }

    public void saveAll() {
        FileConfiguration config = new YamlConfiguration();
        for (Kit kit : kits.values()) {
            String path = "kits." + kit.getName();
            config.set(path + ".type", kit.getType().name());
            config.set(path + ".items", java.util.Arrays.asList(kit.getItems()));
            config.set(path + ".armor", java.util.Arrays.asList(kit.getArmor()));
            config.set(path + ".allow-build", kit.isAllowBuild());
            config.set(path + ".natural-regen", kit.isNaturalRegen());
            config.set(path + ".hunger-loss", kit.isHungerLoss());
            config.set(path + ".fall-damage", kit.isFallDamage());
            config.set(path + ".knockback-multiplier", kit.getKnockbackMultiplier());
            config.set(path + ".effects", kit.getEffects());
        }
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("No se pudo guardar kits.yml: " + e.getMessage());
        }
    }

    public Kit getKit(String name) {
        return kits.get(name.toLowerCase());
    }

    public boolean exists(String name) {
        return kits.containsKey(name.toLowerCase());
    }

    public void addKit(Kit kit) {
        kits.put(kit.getName().toLowerCase(), kit);
        saveAll();
    }

    public void deleteKit(String name) {
        kits.remove(name.toLowerCase());
        saveAll();
    }

    public List<Kit> getKits() {
        return new ArrayList<>(kits.values());
    }

    // ================= KITS PREDEFINIDOS =================

    private void createDefaultKits() {
        kits.put("sword", buildSwordKit());
        kits.put("uhc", buildUhcKit());
        kits.put("pot", buildPotKit());
        kits.put("nodebuff", buildNoDebuffKit());
        kits.put("debuff", buildDebuffKit());
        kits.put("boxing", buildBoxingKit());
        kits.put("sumo", buildSumoKit());
        kits.put("gapple", buildGappleKit());
        kits.put("axe", buildAxeKit());
        kits.put("build", buildBuildKit());
        kits.put("soup", buildSoupKit());
        kits.put("combo", buildComboKit());
        kits.put("spleef", buildSpleefKit());
    }

    private ItemStack[] emptyItems() {
        return new ItemStack[36];
    }

    private ItemStack diamondArmorPiece(Material material) {
        ItemStack stack = new ItemStack(material);
        return stack;
    }

    private Kit buildSwordKit() {
        Kit kit = new Kit("sword", KitType.SWORD);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SWORD);
        for (int i = 1; i <= 8; i++) items[i] = new ItemStack(Material.COOKED_BEEF, 64);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.DIAMOND_BOOTS),
                new ItemStack(Material.DIAMOND_LEGGINGS),
                new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_HELMET)
        });
        kit.setNaturalRegen(true);
        return kit;
    }

    private Kit buildUhcKit() {
        Kit kit = new Kit("uhc", KitType.UHC);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SWORD);
        items[1] = new ItemStack(Material.BOW);
        items[2] = new ItemStack(Material.ARROW, 32);
        items[3] = new ItemStack(Material.GOLDEN_APPLE, 16);
        items[4] = new ItemStack(Material.COOKED_BEEF, 32);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.IRON_BOOTS),
                new ItemStack(Material.IRON_LEGGINGS),
                new ItemStack(Material.IRON_CHESTPLATE),
                new ItemStack(Material.IRON_HELMET)
        });
        kit.setNaturalRegen(false);
        return kit;
    }

    private Kit buildPotKit() {
        Kit kit = new Kit("pot", KitType.POT);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SWORD);
        for (int i = 1; i <= 7; i++) {
            ItemStack pot = new ItemStack(Material.SPLASH_POTION);
            items[i] = pot;
        }
        items[8] = new ItemStack(Material.GOLDEN_APPLE, 8);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.IRON_BOOTS),
                new ItemStack(Material.IRON_LEGGINGS),
                new ItemStack(Material.IRON_CHESTPLATE),
                new ItemStack(Material.IRON_HELMET)
        });
        kit.setNaturalRegen(false);
        return kit;
    }

    private Kit buildNoDebuffKit() {
        Kit kit = new Kit("nodebuff", KitType.NODEBUFF);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SWORD);
        items[1] = new ItemStack(Material.GOLDEN_APPLE, 16);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.DIAMOND_BOOTS),
                new ItemStack(Material.DIAMOND_LEGGINGS),
                new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_HELMET)
        });
        kit.setNaturalRegen(false);
        return kit;
    }

    private Kit buildDebuffKit() {
        Kit kit = new Kit("debuff", KitType.DEBUFF);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SWORD);
        for (int i = 1; i <= 4; i++) items[i] = new ItemStack(Material.SPLASH_POTION);
        items[5] = new ItemStack(Material.GOLDEN_APPLE, 8);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.DIAMOND_BOOTS),
                new ItemStack(Material.DIAMOND_LEGGINGS),
                new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_HELMET)
        });
        kit.getEffects().add(new PotionEffect(PotionEffectType.WEAKNESS, Integer.MAX_VALUE, 0, false, false));
        kit.setNaturalRegen(false);
        return kit;
    }

    private Kit buildBoxingKit() {
        Kit kit = new Kit("boxing", KitType.BOXING);
        kit.setItems(emptyItems());
        kit.setArmor(new ItemStack[4]);
        kit.setNaturalRegen(true);
        return kit;
    }

    private Kit buildSumoKit() {
        Kit kit = new Kit("sumo", KitType.SUMO);
        kit.setItems(emptyItems());
        kit.setArmor(new ItemStack[4]);
        kit.setKnockbackMultiplier(1.8);
        kit.setNaturalRegen(true);
        kit.setFallDamage(false);
        return kit;
    }

    private Kit buildGappleKit() {
        Kit kit = new Kit("gapple", KitType.GAPPLE);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SWORD);
        items[1] = new ItemStack(Material.GOLDEN_APPLE, 32);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.IRON_BOOTS),
                new ItemStack(Material.IRON_LEGGINGS),
                new ItemStack(Material.IRON_CHESTPLATE),
                new ItemStack(Material.IRON_HELMET)
        });
        return kit;
    }

    private Kit buildAxeKit() {
        Kit kit = new Kit("axe", KitType.AXE);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_AXE);
        items[1] = new ItemStack(Material.GOLDEN_APPLE, 8);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.DIAMOND_BOOTS),
                new ItemStack(Material.DIAMOND_LEGGINGS),
                new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_HELMET)
        });
        return kit;
    }

    private Kit buildBuildKit() {
        Kit kit = new Kit("build", KitType.BUILD);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_PICKAXE);
        items[1] = new ItemStack(Material.DIAMOND_SWORD);
        items[2] = new ItemStack(Material.SANDSTONE, 64);
        kit.setItems(items);
        kit.setAllowBuild(true);
        return kit;
    }

    private Kit buildSoupKit() {
        Kit kit = new Kit("soup", KitType.SOUP);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.STONE_SWORD);
        for (int i = 1; i <= 8; i++) items[i] = new ItemStack(Material.MUSHROOM_STEW);
        kit.setItems(items);
        kit.setArmor(new ItemStack[]{
                new ItemStack(Material.CHAINMAIL_BOOTS),
                new ItemStack(Material.CHAINMAIL_LEGGINGS),
                new ItemStack(Material.CHAINMAIL_CHESTPLATE),
                new ItemStack(Material.CHAINMAIL_HELMET)
        });
        return kit;
    }

    private Kit buildComboKit() {
        Kit kit = new Kit("combo", KitType.COMBO);
        ItemStack[] items = emptyItems();
        ItemStack sword = new ItemStack(Material.STONE_SWORD);
        sword.addUnsafeEnchantment(Enchantment.KNOCKBACK, 2);
        items[0] = sword;
        kit.setItems(items);
        kit.setKnockbackMultiplier(1.4);
        kit.setNaturalRegen(true);
        return kit;
    }

    private Kit buildSpleefKit() {
        Kit kit = new Kit("spleef", KitType.SPLEEF);
        ItemStack[] items = emptyItems();
        items[0] = new ItemStack(Material.DIAMOND_SHOVEL);
        kit.setItems(items);
        kit.setAllowBuild(true);
        kit.setFallDamage(false);
        return kit;
    }
}
