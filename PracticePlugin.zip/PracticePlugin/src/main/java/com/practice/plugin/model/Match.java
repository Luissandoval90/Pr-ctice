package com.practice.plugin.model;

import org.bukkit.entity.Player;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Representa una partida activa. Soporta 1vs1, 2vs2, 3vs3 ... NvN,
 * asi como enfrentamientos de party contra party. El equipo se
 * determina por pertenecer al set teamA o teamB.
 */
public class Match {

    private final String id;
    private final Kit kit;
    private final Arena arena;
    private final Set<UUID> teamA = new LinkedHashSet<>();
    private final Set<UUID> teamB = new LinkedHashSet<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final Set<UUID> spectators = new LinkedHashSet<>();

    private MatchState state = MatchState.STARTING;
    private final boolean ranked;
    private boolean ffa = false;

    public Match(String id, Kit kit, Arena arena, boolean ranked) {
        this.id = id;
        this.kit = kit;
        this.arena = arena;
        this.ranked = ranked;
    }

    public boolean isFfa() {
        return ffa;
    }

    public void setFfa(boolean ffa) {
        this.ffa = ffa;
    }

    public String getId() {
        return id;
    }

    public Kit getKit() {
        return kit;
    }

    public Arena getArena() {
        return arena;
    }

    public Set<UUID> getTeamA() {
        return teamA;
    }

    public Set<UUID> getTeamB() {
        return teamB;
    }

    public Set<UUID> getAlive() {
        return alive;
    }

    public Set<UUID> getSpectators() {
        return spectators;
    }

    public MatchState getState() {
        return state;
    }

    public void setState(MatchState state) {
        this.state = state;
    }

    public boolean isRanked() {
        return ranked;
    }

    public boolean isTeamSize1() {
        return teamA.size() == 1 && teamB.size() == 1;
    }

    public int totalPlayers() {
        return teamA.size() + teamB.size();
    }

    public boolean isParticipant(UUID uuid) {
        return teamA.contains(uuid) || teamB.contains(uuid);
    }

    public Set<UUID> getTeamOf(UUID uuid) {
        if (teamA.contains(uuid)) return teamA;
        if (teamB.contains(uuid)) return teamB;
        return null;
    }

    public Set<UUID> getEnemyTeamOf(UUID uuid) {
        if (teamA.contains(uuid)) return teamB;
        if (teamB.contains(uuid)) return teamA;
        return null;
    }

    /** Elimina al jugador de "vivos" y lo pasa a espectadores. Devuelve true si la partida debe terminar. */
    public boolean eliminate(UUID uuid) {
        alive.remove(uuid);
        spectators.add(uuid);

        if (ffa) {
            return alive.size() <= 1;
        }

        Set<UUID> team = getTeamOf(uuid);
        if (team == null) return false;
        for (UUID member : team) {
            if (alive.contains(member)) return false;
        }
        return true;
    }

    /** Devuelve el set del equipo/jugador ganador una vez la partida termina, o null si no ha terminado. */
    public Set<UUID> getWinningTeam() {
        if (ffa) {
            if (alive.size() == 1) return new LinkedHashSet<>(alive);
            return null;
        }
        boolean aAlive = teamA.stream().anyMatch(alive::contains);
        boolean bAlive = teamB.stream().anyMatch(alive::contains);
        if (aAlive && !bAlive) return teamA;
        if (bAlive && !aAlive) return teamB;
        return null;
    }
}
