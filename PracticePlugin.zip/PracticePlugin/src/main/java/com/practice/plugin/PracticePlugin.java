package com.practice.plugin;

import com.practice.plugin.command.*;
import com.practice.plugin.listener.MatchListener;
import com.practice.plugin.listener.PlayerConnectionListener;
import com.practice.plugin.manager.*;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Clase principal del plugin. Inicializa todos los managers, registra
 * comandos y listeners, y expone accesos globales.
 */
public class PracticePlugin extends JavaPlugin {

    private static PracticePlugin instance;

    private KitManager kitManager;
    private ArenaManager arenaManager;
    private MatchManager matchManager;
    private PartyManager partyManager;
    private RequestManager requestManager;
    private ScoreboardManager scoreboardManager;
    private PlayerDataManager playerDataManager;
    private FileConfiguration messages;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveResourceIfMissing("messages.yml");
        loadMessages();

        this.kitManager = new KitManager(this);
        this.arenaManager = new ArenaManager(this);
        this.matchManager = new MatchManager(this);
        this.partyManager = new PartyManager();
        this.requestManager = new RequestManager();
        this.scoreboardManager = new ScoreboardManager(this);
        this.playerDataManager = new PlayerDataManager(this);

        registerCommands();
        registerListeners();

        scoreboardManager.start();

        getLogger().info("PracticePlugin habilitado correctamente. Kits cargados: " + kitManager.getKits().size());
    }

    @Override
    public void onDisable() {
        if (playerDataManager != null) playerDataManager.saveAll();
        if (kitManager != null) kitManager.saveAll();
        if (arenaManager != null) arenaManager.saveAll();
        getLogger().info("PracticePlugin deshabilitado.");
    }

    private void registerCommands() {
        getCommand("kit").setExecutor(new KitCommand(this));
        getCommand("arena").setExecutor(new ArenaCommand(this));
        getCommand("duelo").setExecutor(new DuelCommand(this));
        getCommand("party").setExecutor(new PartyCommand(this));
        getCommand("practice").setExecutor(new PracticeAdminCommand(this));
        getCommand("ffa").setExecutor(new FfaCommand(this));
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new MatchListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerConnectionListener(this), this);
    }

    private void saveResourceIfMissing(String name) {
        File file = new File(getDataFolder(), name);
        if (!file.exists()) {
            saveResource(name, false);
        }
    }

    private void loadMessages() {
        File file = new File(getDataFolder(), "messages.yml");
        messages = YamlConfiguration.loadConfiguration(file);
    }

    public String msg(String key) {
        String value = messages.getString(key, key);
        return ColorUtil.c(value);
    }

    public String prefix() {
        return getConfig().getString("general.prefix", "&8[&bPractice&8] &r");
    }

    public static PracticePlugin get() {
        return instance;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public MatchManager getMatchManager() {
        return matchManager;
    }

    public PartyManager getPartyManager() {
        return partyManager;
    }

    public RequestManager getRequestManager() {
        return requestManager;
    }

    public ScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }
}
