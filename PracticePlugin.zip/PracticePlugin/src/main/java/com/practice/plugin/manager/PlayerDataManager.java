package com.practice.plugin.manager;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.PlayerData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Guarda y carga estadisticas de jugadores (wins, losses, killstreak).
 */
public class PlayerDataManager {

    private final PracticePlugin plugin;
    private final Map<UUID, PlayerData> cache = new HashMap<>();
    private File file;

    public PlayerDataManager(PracticePlugin plugin) {
        this.plugin = plugin;
        file = new File(plugin.getDataFolder(), "stats.yml");
    }

    public PlayerData get(UUID uuid) {
        return cache.computeIfAbsent(uuid, id -> loadOrCreate(id));
    }

    private PlayerData loadOrCreate(UUID uuid) {
        if (!file.exists()) return new PlayerData(uuid);
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection(uuid.toString());
        PlayerData data = new PlayerData(uuid);
        if (section != null) {
            for (int i = 0; i < section.getInt("wins", 0); i++) data.addWin();
            for (int i = 0; i < section.getInt("losses", 0); i++) data.addLoss();
        }
        return data;
    }

    public void saveAll() {
        FileConfiguration config = new YamlConfiguration();
        for (PlayerData data : cache.values()) {
            String path = data.getUuid().toString();
            config.set(path + ".wins", data.getWins());
            config.set(path + ".losses", data.getLosses());
            config.set(path + ".bestKillstreak", data.getBestKillstreak());
        }
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("No se pudo guardar stats.yml: " + e.getMessage());
        }
    }
}
