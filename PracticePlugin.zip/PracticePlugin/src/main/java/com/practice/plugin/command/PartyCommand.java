package com.practice.plugin.command;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Kit;
import com.practice.plugin.model.Party;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Sistema de parties/clanes para duelos por equipos:
 * /party crear
 * /party invitar <jugador>
 * /party aceptar <lider>
 * /party salir
 * /party lista
 * /party duelo <liderRival> <kit>          - reta a otra party completa (NvN)
 * /party duelo aceptar <liderRival>
 */
public class PartyCommand implements CommandExecutor {

    private final PracticePlugin plugin;

    public PartyCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtil.c(plugin.msg("player-only")));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ColorUtil.c("&cUso: /party <crear|invitar|aceptar|salir|lista|duelo>"));
            return true;
        }

        var partyManager = plugin.getPartyManager();
        String sub = args[0].toLowerCase();

        switch (sub) {
            case "crear" -> {
                if (partyManager.isInParty(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.c("&cYa perteneces a una party. Usa /party salir primero."));
                    return true;
                }
                partyManager.createParty(player);
                player.sendMessage(ColorUtil.c(plugin.msg("party-created")));
            }
            case "invitar" -> {
                if (args.length < 2) {
                    player.sendMessage(ColorUtil.c("&cUso: /party invitar <jugador>"));
                    return true;
                }
                Party party = partyManager.getParty(player.getUniqueId());
                if (party == null || !party.isLeader(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.c("&cDebes ser lider de una party para invitar."));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    player.sendMessage(ColorUtil.c("&cEse jugador no esta conectado."));
                    return true;
                }
                partyManager.invite(player.getUniqueId(), target.getUniqueId());
                player.sendMessage(ColorUtil.c(plugin.msg("party-invited").replace("%player%", target.getName())));
                target.sendMessage(ColorUtil.c(plugin.msg("party-invite-received").replace("%player%", player.getName())));
            }
            case "aceptar" -> {
                if (args.length < 2) {
                    player.sendMessage(ColorUtil.c("&cUso: /party aceptar <lider>"));
                    return true;
                }
                Player leader = Bukkit.getPlayerExact(args[1]);
                if (leader == null) {
                    player.sendMessage(ColorUtil.c("&cEse jugador no esta conectado."));
                    return true;
                }
                UUID inviter = partyManager.pollInvite(player.getUniqueId(), leader.getUniqueId());
                if (inviter == null) {
                    player.sendMessage(ColorUtil.c("&cNo tienes ninguna invitacion de ese jugador."));
                    return true;
                }
                Party party = partyManager.getParty(inviter);
                if (party == null) {
                    player.sendMessage(ColorUtil.c("&cLa party ya no existe."));
                    return true;
                }
                partyManager.join(player.getUniqueId(), party);
                player.sendMessage(ColorUtil.c(plugin.msg("party-joined").replace("%leader%", leader.getName())));
            }
            case "salir" -> {
                if (!partyManager.isInParty(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.c(plugin.msg("party-not-in")));
                    return true;
                }
                partyManager.leave(player.getUniqueId());
                player.sendMessage(ColorUtil.c("&aHas salido de la party."));
            }
            case "lista" -> {
                Party party = partyManager.getParty(player.getUniqueId());
                if (party == null) {
                    player.sendMessage(ColorUtil.c(plugin.msg("party-not-in")));
                    return true;
                }
                String names = party.getMembers().stream()
                        .map(Bukkit::getPlayer)
                        .filter(java.util.Objects::nonNull)
                        .map(Player::getName)
                        .collect(Collectors.joining(", "));
                player.sendMessage(ColorUtil.c("&bMiembros de la party: &f" + names));
            }
            case "duelo" -> handlePartyDuel(player, args);
            default -> player.sendMessage(ColorUtil.c("&cUso: /party <crear|invitar|aceptar|salir|lista|duelo>"));
        }
        return true;
    }

    private void handlePartyDuel(Player player, String[] args) {
        var partyManager = plugin.getPartyManager();
        Party myParty = partyManager.getParty(player.getUniqueId());
        if (myParty == null || !myParty.isLeader(player.getUniqueId())) {
            player.sendMessage(ColorUtil.c("&cDebes ser lider de una party para retar a otra."));
            return;
        }

        if (args.length >= 2 && args[1].equalsIgnoreCase("aceptar")) {
            if (args.length < 3) {
                player.sendMessage(ColorUtil.c("&cUso: /party duelo aceptar <liderRival>"));
                return;
            }
            Player rivalLeader = Bukkit.getPlayerExact(args[2]);
            if (rivalLeader == null) {
                player.sendMessage(ColorUtil.c("&cEse jugador no esta conectado."));
                return;
            }
            UUID fromLeader = partyManager.pollPartyDuelRequest(player.getUniqueId(), rivalLeader.getUniqueId());
            if (fromLeader == null) {
                player.sendMessage(ColorUtil.c("&cNo tienes ningun reto de esa party."));
                return;
            }
            Party rivalParty = partyManager.getParty(fromLeader);
            if (rivalParty == null) {
                player.sendMessage(ColorUtil.c("&cLa party rival ya no existe."));
                return;
            }
            Kit kit = pendingKits.remove(fromLeader);
            if (kit == null) kit = plugin.getKitManager().getKit("sword");

            Set<UUID> teamA = new LinkedHashSet<>(myParty.getMembers());
            Set<UUID> teamB = new LinkedHashSet<>(rivalParty.getMembers());
            plugin.getMatchManager().startMatch(teamA, teamB, kit, true);
            return;
        }

        if (args.length < 3) {
            player.sendMessage(ColorUtil.c("&cUso: /party duelo <liderRival> <kit>"));
            return;
        }
        Player rivalLeader = Bukkit.getPlayerExact(args[1]);
        if (rivalLeader == null) {
            player.sendMessage(ColorUtil.c("&cEse jugador no esta conectado."));
            return;
        }
        Party rivalParty = partyManager.getParty(rivalLeader.getUniqueId());
        if (rivalParty == null || !rivalParty.isLeader(rivalLeader.getUniqueId())) {
            player.sendMessage(ColorUtil.c("&cEse jugador no es lider de ninguna party."));
            return;
        }
        String kitName = args[2];
        if (!plugin.getKitManager().exists(kitName)) {
            player.sendMessage(ColorUtil.c(plugin.msg("kit-not-found")));
            return;
        }

        pendingKits.put(player.getUniqueId(), plugin.getKitManager().getKit(kitName));
        partyManager.requestPartyDuel(player.getUniqueId(), rivalLeader.getUniqueId());
        player.sendMessage(ColorUtil.c("&aHas retado a la party de &f" + rivalLeader.getName() +
                "&a (&f" + myParty.size() + "vs" + rivalParty.size() + "&a) con el kit &b" + kitName));
        rivalLeader.sendMessage(ColorUtil.c("&eLa party de &f" + player.getName() +
                " &fte ha retado a un &b" + myParty.size() + "vs" + rivalParty.size() +
                " &fcon el kit &b" + kitName + "&f. Usa &a/party duelo aceptar " + player.getName()));
    }

    // guarda temporalmente el kit propuesto en un reto de party mientras se acepta
    private final java.util.Map<UUID, Kit> pendingKits = new java.util.HashMap<>();
}
