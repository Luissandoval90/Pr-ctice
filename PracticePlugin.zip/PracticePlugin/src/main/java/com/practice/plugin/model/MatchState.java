package com.practice.plugin.model;

public enum MatchState {
    STARTING,   // cuenta regresiva
    RUNNING,    // combate activo
    ENDING      // se esta finalizando (regenerando arena, etc)
}
