package com.practice.plugin.model;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

/**
 * Guarda el estado completo de un jugador antes de entrar en una
 * partida para poder restaurarlo exactamente al terminar.
 */
public class ItemSnapshot {

    private final ItemStack[] contents;
    private final ItemStack[] armor;
    private final Location location;
    private final GameMode gameMode;
    private final double health;
    private final int food;
    private final float exp;
    private final int level;

    public ItemSnapshot(ItemStack[] contents, ItemStack[] armor, Location location,
                         GameMode gameMode, double health, int food, float exp, int level) {
        this.contents = contents;
        this.armor = armor;
        this.location = location;
        this.gameMode = gameMode;
        this.health = health;
        this.food = food;
        this.exp = exp;
        this.level = level;
    }

    public ItemStack[] getContents() {
        return contents;
    }

    public ItemStack[] getArmor() {
        return armor;
    }

    public Location getLocation() {
        return location;
    }

    public GameMode getGameMode() {
        return gameMode;
    }

    public double getHealth() {
        return health;
    }

    public int getFood() {
        return food;
    }

    public float getExp() {
        return exp;
    }

    public int getLevel() {
        return level;
    }
}
