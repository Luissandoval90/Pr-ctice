package com.practice.plugin.manager;

import com.practice.plugin.model.Party;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Administra parties/clanes en memoria: creacion, invitaciones y
 * duelos entre parties completas (NvN).
 */
public class PartyManager {

    private final Map<UUID, Party> partyByMember = new HashMap<>();
    // invitaciones pendientes: invitado -> lider que invito
    private final Map<UUID, UUID> pendingInvites = new HashMap<>();
    // retos de party pendientes: partyLeaderRetado -> partyLeaderRetador
    private final Map<UUID, UUID> partyDuelRequests = new HashMap<>();

    public Party createParty(Player leader) {
        Party party = new Party(leader.getUniqueId());
        partyByMember.put(leader.getUniqueId(), party);
        return party;
    }

    public Party getParty(UUID uuid) {
        return partyByMember.get(uuid);
    }

    public boolean isInParty(UUID uuid) {
        return partyByMember.containsKey(uuid);
    }

    public void invite(UUID inviter, UUID invitee) {
        pendingInvites.put(invitee, inviter);
    }

    public UUID pollInvite(UUID invitee, UUID expectedInviter) {
        UUID inviter = pendingInvites.get(invitee);
        if (inviter != null && inviter.equals(expectedInviter)) {
            pendingInvites.remove(invitee);
            return inviter;
        }
        return null;
    }

    public void join(UUID uuid, Party party) {
        party.addMember(uuid);
        partyByMember.put(uuid, party);
    }

    public void leave(UUID uuid) {
        Party party = partyByMember.remove(uuid);
        if (party == null) return;
        party.removeMember(uuid);
        if (party.isLeader(uuid) || party.size() == 0) {
            // disolver party para el resto
            Set<UUID> remaining = new HashSet<>(party.getMembers());
            for (UUID member : remaining) {
                partyByMember.remove(member);
            }
        }
    }

    public void requestPartyDuel(UUID fromLeader, UUID toLeader) {
        partyDuelRequests.put(toLeader, fromLeader);
    }

    public UUID pollPartyDuelRequest(UUID toLeader, UUID expectedFromLeader) {
        UUID from = partyDuelRequests.get(toLeader);
        if (from != null && from.equals(expectedFromLeader)) {
            partyDuelRequests.remove(toLeader);
            return from;
        }
        return null;
    }
}
