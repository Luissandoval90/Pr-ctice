package com.practice.plugin.manager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Gestiona solicitudes de duelo 1vs1 pendientes entre dos jugadores,
 * incluyendo el kit y el tamano de equipo elegido.
 */
public class RequestManager {

    public static class DuelRequest {
        public final UUID sender;
        public final String kitName;
        public final int teamSize;

        public DuelRequest(UUID sender, String kitName, int teamSize) {
            this.sender = sender;
            this.kitName = kitName;
            this.teamSize = teamSize;
        }
    }

    // objetivo -> solicitud
    private final Map<UUID, DuelRequest> requests = new HashMap<>();

    public void addRequest(UUID target, UUID sender, String kitName, int teamSize) {
        requests.put(target, new DuelRequest(sender, kitName, teamSize));
    }

    public DuelRequest pollRequest(UUID target, UUID expectedSender) {
        DuelRequest req = requests.get(target);
        if (req != null && req.sender.equals(expectedSender)) {
            requests.remove(target);
            return req;
        }
        return null;
    }

    public DuelRequest getAnyRequestFrom(UUID target, UUID sender) {
        DuelRequest req = requests.get(target);
        if (req != null && req.sender.equals(sender)) return req;
        return null;
    }

    public void clear(UUID target) {
        requests.remove(target);
    }
}
