package com.practice.plugin.manager;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.*;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Nucleo del sistema de partidas. Soporta 1vs1 hasta NvN (equipos de
 * cualquier tamano) y partidas entre parties/clanes completos.
 * Gestiona countdown, teletransporte, inventarios, muerte, victoria,
 * efectos de kill (firework + sonido + titulo) y devolucion de jugadores
 * al lobby restaurando su estado previo.
 */
public class MatchManager {

    private final PracticePlugin plugin;
    private final Map<String, Match> matchesById = new HashMap<>();
    private final Map<UUID, Match> matchByPlayer = new HashMap<>();
    private int idCounter = 0;

    public MatchManager(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    public Match getMatch(UUID uuid) {
        return matchByPlayer.get(uuid);
    }

    public boolean isInMatch(UUID uuid) {
        return matchByPlayer.containsKey(uuid);
    }

    /**
     * Crea e inicia una partida entre dos equipos (cualquier tamano, incluyendo
     * 1vs1). teamA y teamB pueden venir de jugadores sueltos o de parties.
     */
    public Match startMatch(Set<UUID> teamA, Set<UUID> teamB, Kit kit, boolean ranked) {
        Arena arena = plugin.getArenaManager().findFreeArena();
        if (arena == null) {
            for (UUID uuid : teamA) notify(uuid, "&cNo hay ninguna arena disponible en este momento.");
            for (UUID uuid : teamB) notify(uuid, "&cNo hay ninguna arena disponible en este momento.");
            return null;
        }
        arena.setInUse(true);

        String id = "match-" + (idCounter++);
        Match match = new Match(id, kit, arena, ranked);
        match.getTeamA().addAll(teamA);
        match.getTeamB().addAll(teamB);
        match.getAlive().addAll(teamA);
        match.getAlive().addAll(teamB);

        matchesById.put(id, match);
        for (UUID uuid : match.getAlive()) {
            matchByPlayer.put(uuid, match);
        }

        prepareBuildSnapshot(match);
        countdown(match);
        return match;
    }

    /** Crea una partida FFA (todos contra todos) con cualquier numero de jugadores. */
    public Match startFfaMatch(Set<UUID> players, Kit kit) {
        Arena arena = plugin.getArenaManager().findFreeArena();
        if (arena == null) {
            for (UUID uuid : players) notify(uuid, "&cNo hay ninguna arena disponible en este momento.");
            return null;
        }
        arena.setInUse(true);

        String id = "ffa-" + (idCounter++);
        Match match = new Match(id, kit, arena, false);
        match.setFfa(true);
        match.getTeamA().addAll(players);
        match.getAlive().addAll(players);

        matchesById.put(id, match);
        for (UUID uuid : players) matchByPlayer.put(uuid, match);

        countdown(match);
        return match;
    }

    private void prepareBuildSnapshot(Match match) {
        if (!match.getKit().isAllowBuild()) return;
        Arena arena = match.getArena();
        if (arena.getPos1() == null || arena.getPos2() == null) return;
        // El snapshot real de bloques se captura de forma perezosa al finalizar,
        // comparando contra el estado original guardado en pos1/pos2 si se desea
        // regeneracion completa; para mantener el rendimiento se recomienda usar
        // WorldEdit/FastAsyncWorldEdit externamente para arenas de build grandes.
    }

    private void countdown(Match match) {
        match.setState(MatchState.STARTING);
        for (UUID uuid : match.getAlive()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) continue;
            savePlayerState(player);
            teleportToTeamSpawn(match, player);
            giveKit(player, match.getKit());
            player.setGameMode(GameMode.SURVIVAL);
            player.getInventory().setHeldItemSlot(0);
        }

        int seconds = plugin.getConfig().getInt("general.countdown-seconds", 5);
        new BukkitRunnable() {
            int left = seconds;

            @Override
            public void run() {
                if (left <= 0) {
                    match.setState(MatchState.RUNNING);
                    broadcast(match, plugin.msg("match-started"));
                    cancel();
                    return;
                }
                broadcast(match, plugin.msg("match-starting").replace("%seconds%", String.valueOf(left)));
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void teleportToTeamSpawn(Match match, Player player) {
        Location base = match.getTeamA().contains(player.getUniqueId())
                ? match.getArena().getSpawn1()
                : match.getArena().getSpawn2();
        if (base == null) return;
        // dispersion para que no aparezcan todos apilados, mayor radio si hay muchos jugadores (FFA/NvN)
        double radius = match.isFfa() ? Math.min(10, 2 + match.totalPlayers() * 0.5) : 1.5;
        Location loc = base.clone();
        loc.setX(loc.getX() + (new Random().nextDouble() - 0.5) * radius);
        loc.setZ(loc.getZ() + (new Random().nextDouble() - 0.5) * radius);
        player.teleport(loc);
    }

    private void giveKit(Player player, Kit kit) {
        player.getInventory().clear();
        player.getInventory().setContents(cloneArray(kit.getItems()));
        player.getInventory().setArmorContents(cloneArray(kit.getArmor()));
        player.setHealth(20.0);
        player.setFoodLevel(20);
        for (var effect : kit.getEffects()) {
            player.addPotionEffect(effect);
        }
    }

    private org.bukkit.inventory.ItemStack[] cloneArray(org.bukkit.inventory.ItemStack[] source) {
        org.bukkit.inventory.ItemStack[] copy = new org.bukkit.inventory.ItemStack[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = source[i] == null ? null : source[i].clone();
        }
        return copy;
    }

    private void savePlayerState(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        ItemSnapshot snapshot = new ItemSnapshot(
                cloneArray(player.getInventory().getContents()),
                cloneArray(player.getInventory().getArmorContents()),
                player.getLocation(),
                player.getGameMode(),
                player.getHealth(),
                player.getFoodLevel(),
                player.getExp(),
                player.getLevel()
        );
        data.setPreMatchInventory(snapshot);
        data.setInMatch(true);
    }

    private void restorePlayerState(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player.getUniqueId());
        ItemSnapshot snapshot = data.getPreMatchInventory();
        player.getInventory().clear();
        player.setGameMode(GameMode.SURVIVAL);
        if (snapshot != null) {
            player.getInventory().setContents(snapshot.getContents());
            player.getInventory().setArmorContents(snapshot.getArmor());
            player.teleport(snapshot.getLocation());
            player.setHealth(Math.max(1.0, snapshot.getHealth()));
            player.setFoodLevel(snapshot.getFood());
            player.setExp(snapshot.getExp());
            player.setLevel(snapshot.getLevel());
        } else {
            teleportToMainSpawn(player);
        }
        player.setFireTicks(0);
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        data.setInMatch(false);
    }

    public void teleportToMainSpawn(Player player) {
        var cfg = plugin.getConfig();
        World world = Bukkit.getWorld(cfg.getString("general.spawn-world", "world"));
        if (world == null) return;
        Location loc = new Location(world,
                cfg.getDouble("general.spawn-x"),
                cfg.getDouble("general.spawn-y"),
                cfg.getDouble("general.spawn-z"));
        player.teleport(loc);
    }

    /** Llamado cuando un jugador muere/es derrotado dentro de una partida. */
    public void handleElimination(Match match, Player killed, Player killer) {
        if (match.getState() != MatchState.RUNNING) return;

        playKillEffect(killed, killer);

        boolean teamEliminated = match.eliminate(killed.getUniqueId());
        broadcast(match, plugin.msg("player-killed")
                .replace("%killed%", killed.getName())
                .replace("%killer%", killer != null ? killer.getName() : "Arena"));

        // convertir en espectador
        killed.setGameMode(GameMode.SPECTATOR);
        Location spec = match.getArena().getSpawn1() != null ? match.getArena().getSpawn1() : killed.getLocation();
        killed.teleport(spec);

        if (teamEliminated) {
            endMatch(match);
        }
    }

    private void playKillEffect(Player killed, Player killer) {
        var cfg = plugin.getConfig();
        if (cfg.getBoolean("kill-effects.firework", true)) {
            Firework firework = (Firework) killed.getWorld().spawnEntity(killed.getLocation(), EntityType.FIREWORK_ROCKET);
            FireworkMeta meta = firework.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                    .withColor(Color.RED, Color.ORANGE)
                    .with(FireworkEffect.Type.BURST)
                    .trail(true)
                    .flicker(true)
                    .build());
            meta.setPower(1);
            firework.setFireworkMeta(meta);
            firework.detonate();
        }
        if (cfg.getBoolean("kill-effects.sound", true)) {
            try {
                Sound sound = Sound.valueOf(cfg.getString("kill-effects.sound-name", "ENTITY_FIREWORK_ROCKET_BLAST"));
                for (Player viewer : Bukkit.getOnlinePlayers()) {
                    viewer.playSound(killed.getLocation(), sound, 1.0f, 1.0f);
                }
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (cfg.getBoolean("kill-effects.title-enabled", true) && killer != null) {
            killer.sendTitle(ColorUtil.c("&a&l+1 KILL"), ColorUtil.c("&7Has eliminado a &f" + killed.getName()), 5, 40, 10);
            killed.sendTitle(ColorUtil.c("&c&lHAS MUERTO"), ColorUtil.c("&7Eliminado por &f" + killer.getName()), 5, 40, 10);
        }
    }

    private void endMatch(Match match) {
        match.setState(MatchState.ENDING);
        Set<UUID> winners = match.getWinningTeam();
        String winnerNames = winners == null ? "Nadie" : winners.stream()
                .map(Bukkit::getPlayer)
                .filter(Objects::nonNull)
                .map(Player::getName)
                .reduce((a, b) -> a + ", " + b)
                .orElse("Nadie");

        broadcast(match, plugin.msg("match-ended").replace("%winner%", winnerNames));

        boolean isWinner;
        for (UUID uuid : allParticipants(match)) {
            Player player = Bukkit.getPlayer(uuid);
            PlayerData data = plugin.getPlayerDataManager().get(uuid);
            isWinner = winners != null && winners.contains(uuid);
            if (isWinner) data.addWin(); else data.addLoss();

            matchByPlayer.remove(uuid);
            if (player != null) {
                restorePlayerState(player);
                plugin.getScoreboardManager().update(player);
            }
        }

        match.getArena().setInUse(false);
        matchesById.remove(match.getId());
    }

    private Set<UUID> allParticipants(Match match) {
        Set<UUID> all = new LinkedHashSet<>();
        all.addAll(match.getTeamA());
        all.addAll(match.getTeamB());
        return all;
    }

    /** Un jugador se desconecta o hace /practice leave en medio de una partida: se cuenta como eliminado. */
    public void forfeit(Player player) {
        Match match = matchByPlayer.get(player.getUniqueId());
        if (match == null) return;
        boolean teamEliminated = match.eliminate(player.getUniqueId());
        matchByPlayer.remove(player.getUniqueId());
        restorePlayerState(player);
        broadcast(match, ColorUtil.c("&e" + player.getName() + " ha abandonado la partida."));
        if (teamEliminated) {
            endMatch(match);
        }
    }

    private void broadcast(Match match, String message) {
        for (UUID uuid : allParticipants(match)) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) player.sendMessage(ColorUtil.c(plugin.prefix() + message));
        }
        for (UUID uuid : match.getSpectators()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) player.sendMessage(ColorUtil.c(plugin.prefix() + message));
        }
    }

    private void notify(UUID uuid, String message) {
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) player.sendMessage(ColorUtil.c(plugin.prefix() + message));
    }
}
