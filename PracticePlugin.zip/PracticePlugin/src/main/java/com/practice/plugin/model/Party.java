package com.practice.plugin.model;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Grupo de jugadores (clan/party) que puede retar a otro grupo a un
 * duelo por equipos (NvN). El lider gestiona invitaciones.
 */
public class Party {

    private UUID leader;
    private final Set<UUID> members = new LinkedHashSet<>();

    public Party(UUID leader) {
        this.leader = leader;
        this.members.add(leader);
    }

    public UUID getLeader() {
        return leader;
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }

    public Set<UUID> getMembers() {
        return members;
    }

    public void addMember(UUID uuid) {
        members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public int size() {
        return members.size();
    }

    public boolean isLeader(UUID uuid) {
        return leader.equals(uuid);
    }
}
