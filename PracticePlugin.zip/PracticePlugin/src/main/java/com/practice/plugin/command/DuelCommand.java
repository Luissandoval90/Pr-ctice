package com.practice.plugin.command;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.manager.RequestManager;
import com.practice.plugin.model.Kit;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * /duelo <jugador> <kit>          - reta a un jugador a un 1vs1
 * /duelo aceptar <jugador>        - acepta un reto pendiente
 * /duelo denegar <jugador>        - rechaza un reto pendiente
 *
 * Para duelos por equipos (2vs2, 3vs3 ... NvN) o entre clanes, usa
 * /party duelo <lider>, que reutiliza este mismo motor de partidas.
 */
public class DuelCommand implements CommandExecutor {

    private final PracticePlugin plugin;

    public DuelCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtil.c(plugin.msg("player-only")));
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ColorUtil.c("&cUso: /duelo <jugador> <kit> | /duelo aceptar <jugador> | /duelo denegar <jugador>"));
            return true;
        }

        if (args[0].equalsIgnoreCase("aceptar")) {
            if (args.length < 2) {
                player.sendMessage(ColorUtil.c("&cUso: /duelo aceptar <jugador>"));
                return true;
            }
            Player sender2 = Bukkit.getPlayerExact(args[1]);
            if (sender2 == null) {
                player.sendMessage(ColorUtil.c("&cEse jugador no esta conectado."));
                return true;
            }
            RequestManager.DuelRequest req = plugin.getRequestManager().pollRequest(player.getUniqueId(), sender2.getUniqueId());
            if (req == null) {
                player.sendMessage(ColorUtil.c(plugin.msg("duel-no-request")));
                return true;
            }
            Kit kit = plugin.getKitManager().getKit(req.kitName);
            if (kit == null) {
                player.sendMessage(ColorUtil.c(plugin.msg("kit-not-found")));
                return true;
            }
            player.sendMessage(ColorUtil.c(plugin.msg("duel-accepted")));
            sender2.sendMessage(ColorUtil.c(plugin.msg("duel-accepted")));

            Set<UUID> teamA = new LinkedHashSet<>();
            teamA.add(sender2.getUniqueId());
            Set<UUID> teamB = new LinkedHashSet<>();
            teamB.add(player.getUniqueId());
            plugin.getMatchManager().startMatch(teamA, teamB, kit, true);
            return true;
        }

        if (args[0].equalsIgnoreCase("denegar")) {
            if (args.length < 2) return true;
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target != null) {
                plugin.getRequestManager().pollRequest(player.getUniqueId(), target.getUniqueId());
                target.sendMessage(ColorUtil.c("&c" + player.getName() + " ha rechazado tu reto de duelo."));
            }
            player.sendMessage(ColorUtil.c("&aReto rechazado."));
            return true;
        }

        // /duelo <jugador> <kit>
        if (args.length < 2) {
            player.sendMessage(ColorUtil.c("&cUso: /duelo <jugador> <kit>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            player.sendMessage(ColorUtil.c("&cEse jugador no esta conectado."));
            return true;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(ColorUtil.c("&cNo puedes retarte a ti mismo."));
            return true;
        }
        String kitName = args[1];
        if (!plugin.getKitManager().exists(kitName)) {
            player.sendMessage(ColorUtil.c(plugin.msg("kit-not-found")));
            return true;
        }
        if (plugin.getMatchManager().isInMatch(player.getUniqueId()) || plugin.getMatchManager().isInMatch(target.getUniqueId())) {
            player.sendMessage(ColorUtil.c("&cUno de los dos jugadores ya esta en una partida."));
            return true;
        }

        plugin.getRequestManager().addRequest(target.getUniqueId(), player.getUniqueId(), kitName, 1);
        player.sendMessage(ColorUtil.c(plugin.msg("duel-sent").replace("%player%", target.getName())));
        target.sendMessage(ColorUtil.c(plugin.msg("duel-received")
                .replace("%player%", player.getName())
                .replace("%kit%", kitName)
                .replace("%size%", "1")));
        return true;
    }
}
