package com.practice.plugin.command;

import com.practice.plugin.PracticePlugin;
import com.practice.plugin.model.Arena;
import com.practice.plugin.model.ArenaType;
import com.practice.plugin.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.stream.Collectors;

/**
 * /arena crear <nombre> [normal|build]
 * /arena pos1 <nombre>
 * /arena pos2 <nombre>
 * /arena spawn1 <nombre>
 * /arena spawn2 <nombre>
 * /arena borrar <nombre>
 * /arena lista
 */
public class ArenaCommand implements CommandExecutor {

    private final PracticePlugin plugin;

    public ArenaCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ColorUtil.c("&cUso: /arena <crear|pos1|pos2|spawn1|spawn2|borrar|lista> [nombre]"));
            return true;
        }
        String sub = args[0].toLowerCase();

        if (sub.equals("lista")) {
            String list = plugin.getArenaManager().getArenas().stream()
                    .map(Arena::getName)
                    .collect(Collectors.joining(", "));
            sender.sendMessage(ColorUtil.c("&bArenas: &f" + list));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtil.c(plugin.msg("player-only")));
            return true;
        }
        if (!player.hasPermission("practice.admin")) {
            player.sendMessage(ColorUtil.c(plugin.msg("no-permission")));
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(ColorUtil.c("&cDebes indicar el nombre de la arena."));
            return true;
        }
        String name = args[1];

        switch (sub) {
            case "crear" -> {
                if (plugin.getArenaManager().exists(name)) {
                    player.sendMessage(ColorUtil.c("&cYa existe una arena con ese nombre."));
                    return true;
                }
                Arena arena = plugin.getArenaManager().create(name);
                if (args.length > 2 && args[2].equalsIgnoreCase("build")) {
                    arena.setType(ArenaType.BUILD);
                } else {
                    arena.setType(ArenaType.NORMAL);
                }
                plugin.getArenaManager().saveAll();
                player.sendMessage(ColorUtil.c(plugin.msg("arena-created").replace("%arena%", name)));
            }
            case "pos1", "pos2", "spawn1", "spawn2" -> {
                Arena arena = plugin.getArenaManager().get(name);
                if (arena == null) {
                    player.sendMessage(ColorUtil.c(plugin.msg("arena-not-found")));
                    return true;
                }
                switch (sub) {
                    case "pos1" -> arena.setPos1(player.getLocation());
                    case "pos2" -> arena.setPos2(player.getLocation());
                    case "spawn1" -> arena.setSpawn1(player.getLocation());
                    case "spawn2" -> arena.setSpawn2(player.getLocation());
                }
                plugin.getArenaManager().saveAll();
                player.sendMessage(ColorUtil.c(plugin.msg("arena-pos-set")
                        .replace("%pos%", sub).replace("%arena%", name)));
            }
            case "borrar" -> {
                if (!plugin.getArenaManager().exists(name)) {
                    player.sendMessage(ColorUtil.c(plugin.msg("arena-not-found")));
                    return true;
                }
                plugin.getArenaManager().delete(name);
                player.sendMessage(ColorUtil.c("&aArena '" + name + "' eliminada."));
            }
            default -> player.sendMessage(ColorUtil.c("&cUso: /arena <crear|pos1|pos2|spawn1|spawn2|borrar|lista>"));
        }
        return true;
    }
}
