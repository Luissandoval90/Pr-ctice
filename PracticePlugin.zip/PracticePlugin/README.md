# PracticePlugin (Paper 1.21.1)

Plugin de "Practice" completo: kits, duelos 1vs1 hasta NvN, parties/clanes,
modo FFA, arenas con soporte de construccion, scoreboard en vivo, efectos
de muerte (firework + sonido + titulo) y estadisticas por jugador.

## Requisitos para compilar
- JDK 21
- Apache Maven 3.9+
- Conexion a internet (para descargar `paper-api` desde el repositorio de PaperMC)

## Como compilar
```bash
cd PracticePlugin
mvn clean package
```
El .jar final queda en `target/PracticePlugin-1.0.0.jar`. Cópialo a la
carpeta `plugins/` de tu servidor Paper 1.21.1 y reinicia.

> Nota: en este entorno no tengo acceso a internet para descargar las
> dependencias de Maven, así que no pude compilar el .jar directamente.
> Te entrego el proyecto fuente completo y listo; el comando de arriba
> lo compila en segundos en cualquier PC con Maven/JDK 21.

## Kits incluidos por defecto
sword, uhc, pot, nodebuff, debuff, boxing, sumo, gapple, axe, build, soup,
combo, spleef. Puedes crear kits ilimitados nuevos con tu inventario actual.

## Comandos principales
- `/kit crear|editar|borrar|lista`
- `/arena crear|pos1|pos2|spawn1|spawn2|borrar|lista`
- `/duelo <jugador> <kit>` y `/duelo aceptar|denegar <jugador>` (1vs1)
- `/party crear|invitar|aceptar|salir|lista`
- `/party duelo <liderRival> <kit>` y `/party duelo aceptar <lider>` (2vs2 ... NvN / clanes)
- `/ffa <kit>` (todos contra todos, arranca automático con 3+ jugadores)
- `/practice reload|stats|arenas|kits|leave`

## Permisos
- `practice.admin` (default: op) — gestión de kits, arenas y reload.

## Configuración
`config.yml`, `messages.yml`, `kits.yml` y `arenas.yml` se generan
automáticamente en `plugins/PracticePlugin/` la primera vez que arranca.

## Notas de diseño
- Sistema de equipos genérico: un mismo `Match` soporta 1vs1, 2vs2, 3vs3...
  NvN y FFA, controlado por `MatchManager` y el modelo `Match`.
- Cada jugador recupera exactamente su inventario, ubicación, vida y
  hambre previos al terminar o abandonar una partida.
- Los kits tipo `build`/`spleef` permiten romper y colocar bloques solo
  dentro de la partida; para regeneración automática de estructuras muy
  grandes se recomienda integrar WorldEdit/FastAsyncWorldEdit (el código
  ya tiene el punto de extensión en `MatchManager#prepareBuildSnapshot`).
